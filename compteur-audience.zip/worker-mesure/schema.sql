-- Compteur d'audience de trouver-mon-ehpad.fr
--
-- Aucune adresse IP, aucun cookie, aucun identifiant : rien n'est écrit ni lu
-- dans le navigateur du visiteur. L'article 82 de la loi Informatique et Libertés
-- ne s'applique donc pas, et aucun bandeau n'est requis.
--
-- Le grain est (jour, heure, chemin, robot). On peut toujours agréger vers le
-- haut — semaine, mois — jamais redescendre : c'est pourquoi on stocke fin.
-- Le jour et l'heure sont ceux de Paris, pas UTC : sinon tout ce qui se passe
-- entre minuit et 2 h tomberait la veille.

CREATE TABLE IF NOT EXISTS vues (
  jour    TEXT    NOT NULL,            -- 'AAAA-MM-JJ', heure de Paris
  heure   INTEGER NOT NULL,            -- 0 à 23 ; -1 = journée compactée
  chemin  TEXT    NOT NULL,            -- chemin seul, jamais la requête ni l'ancre
  robot   INTEGER NOT NULL DEFAULT 0,  -- 1 = robot identifié, compté à part
  vues    INTEGER NOT NULL DEFAULT 0,
  entrees INTEGER NOT NULL DEFAULT 0,  -- arrivées depuis l'extérieur du site
  PRIMARY KEY (jour, heure, chemin, robot)
);

-- Sites référents, au jour : inutile de les ventiler par page et par heure,
-- et les garder à part évite de multiplier la cardinalité de la table vues.
CREATE TABLE IF NOT EXISTS sources (
  jour    TEXT NOT NULL,
  domaine TEXT NOT NULL,
  robot   INTEGER NOT NULL DEFAULT 0,
  vues    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (jour, domaine, robot)
);

-- Pays, au jour, sur les seules entrées : Cloudflare le fournit sans que rien
-- ne soit stocké côté visiteur.
CREATE TABLE IF NOT EXISTS pays (
  jour     TEXT NOT NULL,
  code     TEXT NOT NULL,
  visites  INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (jour, code)
);

CREATE INDEX IF NOT EXISTS idx_vues_jour   ON vues (jour, robot);
CREATE INDEX IF NOT EXISTS idx_vues_chemin ON vues (chemin, jour);
