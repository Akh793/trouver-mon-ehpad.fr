/**
 * Tests du compteur, sans déploiement : D1 est remplacé par une table en
 * mémoire qui reconnaît les quelques requêtes réellement utilisées.
 *   node worker-mesure/test.mjs
 */
import worker, { quand, chemin, domaine, estRobot } from './index.js';

// ── Base simulée : suffisante pour les UPSERT et les agrégats du compteur.
function faireDB() {
  const t = { vues: [], sources: [], pays: [] };
  const cle = (table, a) => table === 'vues' ? a.slice(0, 4).join('|')
             : table === 'sources' ? a.slice(0, 3).join('|') : a.slice(0, 2).join('|');
  function prepare(sql) {
    const ctx = { sql, args: [] };
    return {
      bind(...a) { ctx.args = a; return this; },
      async run() {
        const m = /^INSERT INTO (\w+)/.exec(ctx.sql.trim());
        if (!m) return {};
        const nom = m[1], k = cle(nom, ctx.args);
        const existant = t[nom].find((l) => l.__k === k);
        if (nom === 'vues') {
          const [jour, heure, ch, robot, entree] = ctx.args;
          if (existant) { existant.vues += 1; existant.entrees += entree; }
          else t[nom].push({ __k: k, jour, heure, chemin: ch, robot, vues: 1, entrees: entree });
        } else if (nom === 'sources') {
          const [jour, d, robot] = ctx.args;
          if (existant) existant.vues += 1;
          else t[nom].push({ __k: k, jour, domaine: d, robot, vues: 1 });
        } else {
          const [jour, code] = ctx.args;
          if (existant) existant.visites += 1;
          else t[nom].push({ __k: k, jour, code, visites: 1 });
        }
        return {};
      },
      async all() {
        // Seules les lectures de l'écran sont simulées, grossièrement : les
        // tests de lecture portent sur le contrôle d'accès, pas sur le SQL.
        const nom = /FROM (\w+)/.exec(ctx.sql)[1];
        return { results: t[nom] };
      },
    };
  }
  return { t, prepare, async batch(l) { for (const x of l) await x.run(); return []; } };
}

const DB = faireDB();
const env = { DB, CLE_MESURE: 'cle-de-test' };
const UA_HUMAIN = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36';
const UA_GOOGLE = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';

const vue = (q, ua = UA_HUMAIN, cf = { country: 'FR' }) => worker.fetch(
  Object.assign(new Request('https://x/v?' + q, { method: 'POST', headers: { 'User-Agent': ua } }),
                { cf }), env);

const cas = [];
const test = (n, f) => cas.push([n, f]);
const lignes = () => DB.t.vues;

test('une vue est enregistrée au bon grain', async () => {
  const r = await vue('p=/prix-ehpad/&e=1');
  const l = lignes()[0];
  return r.status === 204 && lignes().length === 1 && l.chemin === '/prix-ehpad/'
      && l.vues === 1 && l.entrees === 1 && l.robot === 0
      && /^\d{4}-\d{2}-\d{2}$/.test(l.jour) && l.heure >= 0 && l.heure <= 23;
});

test('une seconde vue incrémente au lieu de créer une ligne', async () => {
  const avant = lignes().length;
  await vue('p=/prix-ehpad/&e=0');
  const l = lignes().find((x) => x.chemin === '/prix-ehpad/' && x.robot === 0);
  return lignes().length === avant && l.vues === 2 && l.entrees === 1;   // entrée non recomptée
});

test('Googlebot est compté, mais sur une ligne séparée', async () => {
  await vue('p=/prix-ehpad/&e=1', UA_GOOGLE);
  const h = lignes().find((x) => x.chemin === '/prix-ehpad/' && x.robot === 0);
  const r = lignes().find((x) => x.chemin === '/prix-ehpad/' && x.robot === 1);
  return !!r && r.vues === 1 && h.vues === 2;   // la ligne humaine n'a pas bougé
});

test('la chaîne de requête et l’ancre ne sont jamais enregistrées', async () => {
  await vue('p=' + encodeURIComponent('/calcul/?revenus=1600&gir=2#total') + '&e=1');
  return lignes().some((x) => x.chemin === '/calcul/')
      && !lignes().some((x) => /[?#=]/.test(x.chemin));
});

test('un chemin fantaisiste est assaini et borné', () => {
  return chemin('sans-slash') === '/sans-slash'
      && chemin('/a//b') === '/a/b'
      && chemin('/<script>') === '/script'
      && chemin('/' + 'a'.repeat(300)).length === 120
      && chemin('') === '/' && chemin(null) === '/';
});

test('le domaine référent est réduit et normalisé', () => {
  return domaine('WWW.Google.fr') === 'google.fr'
      && domaine('https://x.com/a?b') === 'httpsx.com/ab'.replace(/[^a-z0-9.\-]/g, '')
      && domaine(null) === '';
});

test('un référent externe alimente les sources', async () => {
  await vue('p=/&e=1&r=google.fr');
  const s = DB.t.sources.find((x) => x.domaine === 'google.fr' && x.robot === 0);
  return !!s && s.vues === 1;
});

test('une navigation interne n’écrit aucune source ni aucune entrée', async () => {
  const avantS = DB.t.sources.length;
  await vue('p=/guides/&e=0');
  const l = lignes().find((x) => x.chemin === '/guides/' && x.robot === 0);
  return DB.t.sources.length === avantS && l.entrees === 0 && l.vues === 1;
});

test('le pays n’est relevé que sur une entrée humaine', async () => {
  const avant = DB.t.pays.length;
  await vue('p=/x1/&e=0');                       // pas une entrée
  await vue('p=/x2/&e=1', UA_GOOGLE);            // un robot
  const apres = DB.t.pays.length;
  await vue('p=/x3/&e=1');                       // entrée humaine
  return apres === avant && DB.t.pays.some((p) => p.code === 'FR');
});

test('aucune adresse IP n’est enregistrée, nulle part', async () => {
  await worker.fetch(Object.assign(new Request('https://x/v?p=/&e=1', {
    method: 'POST', headers: { 'User-Agent': UA_HUMAIN, 'CF-Connecting-IP': '203.0.113.9' } }),
    { cf: { country: 'FR' } }), env);
  const tout = JSON.stringify(DB.t);
  return !tout.includes('203.0.113') && !/\b\d{1,3}(\.\d{1,3}){3}\b/.test(tout);
});

test('le jour et l’heure sont ceux de Paris, pas UTC', () => {
  // 31 décembre 2026, 23 h 30 UTC → 1er janvier 2027, 0 h 30 à Paris.
  const a = quand(new Date('2026-12-31T23:30:00Z'));
  // 1er juillet 2026, 22 h 30 UTC → 2 juillet, 0 h 30 à Paris (heure d'été).
  const b = quand(new Date('2026-07-01T22:30:00Z'));
  return a.jour === '2027-01-01' && a.heure === 0
      && b.jour === '2026-07-02' && b.heure === 0;
});

test('un agent utilisateur absent est traité comme un robot', () => {
  return estRobot('') === true && estRobot(null) === true
      && estRobot(UA_GOOGLE) === true && estRobot(UA_HUMAIN) === false
      && estRobot('curl/8.4.0') === true && estRobot('GPTBot/1.0') === true;
});

test('une erreur de base ne fait jamais échouer le relevé', async () => {
  const casse = { DB: { prepare() { throw new Error('base indisponible'); } }, CLE_MESURE: 'x' };
  const r = await worker.fetch(new Request('https://x/v?p=/&e=1', { method: 'POST' }), casse);
  return r.status === 204;
});

test('l’écran de mesure est refusé sans la clé', async () => {
  const r = await worker.fetch(new Request('https://x/mesure'), env);
  return r.status === 403;
});

test('l’écran de mesure est refusé avec une mauvaise clé', async () => {
  const r = await worker.fetch(new Request('https://x/mesure?cle=faux'), env);
  return r.status === 403;
});

test('avec la bonne clé, l’écran répond et porte un noindex', async () => {
  const r = await worker.fetch(new Request('https://x/mesure?cle=cle-de-test'), env);
  const html = await r.text();
  return r.status === 200 && r.headers.get('X-Robots-Tag').includes('noindex')
      && html.includes('Par jour') && html.includes('Par semaine') && html.includes('Par mois');
});

test('la sortie JSON est servie sur la même clé', async () => {
  const r = await worker.fetch(new Request('https://x/mesure.json?cle=cle-de-test'), env);
  const d = await r.json();
  return r.status === 200 && 'jour' in d && 'semaine' in d && 'mois' in d && 'pages' in d;
});

test('l’écran échappe ce qui vient de l’extérieur', async () => {
  DB.t.vues.push({ jour: '2026-01-01', heure: 3, chemin: '<script>alert(1)</script>',
                   robot: 0, vues: 1, entrees: 0 });
  const html = await (await worker.fetch(new Request('https://x/mesure?cle=cle-de-test'), env)).text();
  DB.t.vues.pop();
  return !html.includes('<script>alert') && html.includes('&lt;script&gt;');
});

test('une route inconnue répond 404', async () => {
  const r = await worker.fetch(new Request('https://x/nimporte'), env);
  return r.status === 404;
});

test('l’origine autorisée est le site', async () => {
  const r = await vue('p=/&e=1');
  return r.headers.get('Access-Control-Allow-Origin') === 'https://trouver-mon-ehpad.fr';
});

let ok = 0;
for (const [nom, fn] of cas) {
  let pass = false;
  try { pass = !!(await fn()); } catch (e) { console.error('   ', e.message); }
  ok += pass;
  console.log(`${pass ? '✅' : '❌'} ${nom}`);
}
console.log(`\n${ok}/${cas.length} tests du compteur OK`);
process.exit(ok === cas.length ? 0 : 1);
