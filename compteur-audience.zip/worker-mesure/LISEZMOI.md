# Compteur d'audience — déploiement

Service **séparé** de celui des retours, et base séparée. Le plan gratuit alloue
100 000 requêtes par jour : un pic de trafic ne doit pas empêcher un visiteur de
déposer un message. Deux Workers, deux destins.

**Gratuit jusqu'à 100 000 pages vues par jour** — environ 3 millions par mois.

---

## 1. Créer la base

```bash
cd worker-mesure
wrangler d1 create mesure-tme
```

Recopier le `database_id` affiché dans `wrangler.toml`, à la place de
`A_REMPLACER_PAR_L_ID_RENVOYE_A_LA_CREATION`. Puis créer les tables :

```bash
wrangler d1 execute mesure-tme --remote --file=schema.sql
```

## 2. Poser la clé de lecture

```bash
wrangler secret put CLE_MESURE      # mot de passe de l'écran d'audience : long et unique
```

Elle ne protège que la **lecture**. Sans elle, l'écran renvoie 403.

## 3. Déployer

```bash
wrangler deploy
```

La commande affiche l'adresse, de la forme `https://mesure-tme.VOTRE-COMPTE.workers.dev`.

## 4. Brancher le site

Ouvrir `build/mesure.py`, remplacer la valeur de `API` par cette adresse, puis
reconstruire les trois familles de pages :

```bash
cd build
python3 build_site.py          # accueil
python3 build_pages.py         # pages annexes
python3 build_retours.py       # page des retours
cd seo && python3 build_seo.py # les 7 903 pages de contenu
```

Contrôle avant de committer — les deux nombres doivent être égaux :

```bash
grep -rl 'sendBeacon' --include='*.html' ../site | wc -l
grep -rl 'tb-avis'    --include='*.html' ../site | wc -l
```

Tant que `API` porte encore `VOTRE-SOUS-DOMAINE`, les pages reçoivent un
commentaire HTML à la place de l'extrait : rien n'est envoyé, rien ne casse.

---

## Lire les chiffres

```
https://mesure-tme.VOTRE-COMPTE.workers.dev/mesure?cle=VOTRE_CLE
```

Par jour, par semaine, par mois, heures de consultation, pages les plus vues,
sites référents, pays. `?jours=365` élargit la fenêtre (90 par défaut, 1095 au
maximum). `/mesure.json?cle=…` renvoie les mêmes données en JSON.

L'écran porte un `noindex` et n'est servi que par le service lui-même : rien
n'est déposé sur le site.

## Ce qui est enregistré, et ce qui ne l'est pas

| Donnée | Enregistrée ? |
|---|---|
| Chemin de la page (`/ehpad/abbeville/`) | Oui |
| Jour et heure, **heure de Paris** | Oui |
| Domaine du site référent (`google.fr`) | Oui, le domaine seul |
| Pays, sur les entrées | Oui, le code à deux lettres |
| Robot ou non | Oui, sur une ligne séparée |
| Chaîne de requête, ancre | **Jamais** — les liens de partage y portent la situation du visiteur |
| Adresse IP | **Jamais**, ni en clair ni sous forme d'empreinte |
| Cookie, `localStorage`, identifiant | **Aucun** |

Rien n'étant lu ni écrit dans le terminal du visiteur, l'article 82 de la loi
Informatique et Libertés ne s'applique pas : **aucun bandeau n'est requis** pour
ce compteur. Cela ne dispense pas de le mentionner dans les mentions légales.

## Le grain, et pourquoi il est fin

Une ligne par `(jour, heure, chemin, robot)`. On agrège toujours vers le haut,
jamais vers le bas : semaine et mois sont des `GROUP BY` sur cette table. Si le
stockage était mensuel, le journalier serait perdu à jamais.

Au-delà de **400 jours**, la tâche de 3 h 45 replie les 24 lignes horaires d'une
page en une seule (`heure = -1`). Le total du jour reste intact, le détail
horaire disparaît, le volume est divisé par vingt-quatre.

## Les robots

Un relevé fondé sur JavaScript écarte déjà l'essentiel des robots, qui ne
l'exécutent pas. Googlebot, lui, le fait. Sans filtre, les premiers mois d'un
site neuf montreraient une courbe d'indexation prise pour de l'audience. Les
robots identifiés ne sont pas jetés mais rangés dans une colonne à part : savoir
que Google parcourt les 7 903 pages est en soi une information utile.

## Ce que ce compteur ne dira jamais

Visiteurs uniques, sessions, parcours d'une page à l'autre. C'est impossible
sans identifiant — c'est le prix de l'absence de bandeau, pas une limite
technique. Il ne dira pas non plus la vérité absolue : un visiteur qui bloque
les scripts n'est pas compté, et n'importe qui peut appeler `/v` à la main pour
gonfler un chiffre. Aucun relevé posé côté navigateur n'échappe à cela —
Google Analytics et Cloudflare Web Analytics compris.

## Vérifier sans déployer

```bash
node worker-mesure/test.mjs   # 20 tests du service
node build/t_mesure.mjs       # 7 tests de l'extrait, dans un vrai navigateur
```

Le second exige que le site soit servi en local sur le port 8899 et que
`build/mesure.py` pointe vers `http://127.0.0.1:8901`.
