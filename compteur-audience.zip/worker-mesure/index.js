/**
 * Compteur d'audience de trouver-mon-ehpad.fr — Worker séparé.
 *
 * Séparé du service de retours à dessein : le plan gratuit alloue 100 000
 * requêtes par jour, et un pic de trafic ne doit pas empêcher un visiteur de
 * déposer un message. Deux Workers, deux bases, deux destins.
 *
 * Ce que le service reçoit : un chemin, un domaine référent, un drapeau
 * d'entrée. Ce qu'il lit lui-même : l'agent utilisateur (pour écarter les
 * robots) et le pays fourni par Cloudflare. Ce qu'il n'écrit jamais : l'IP,
 * la chaîne de requête, l'ancre, un identifiant quelconque.
 */

const ORIGINE = 'https://trouver-mon-ehpad.fr';

// Le jour et l'heure sont ceux de Paris. En UTC, une consultation à 1 h du
// matin serait comptée la veille — invisible sur un mois, faux sur un jour.
const HORLOGE = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Europe/Paris', year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', hour12: false,
});

export function quand(date) {
  const p = {};
  for (const m of HORLOGE.formatToParts(date)) p[m.type] = m.value;
  // Selon la version d'ICU, minuit se formate « 00 » ou « 24 ».
  return { jour: `${p.year}-${p.month}-${p.day}`, heure: Number(p.hour) % 24 };
}

// Un relevé fondé sur JavaScript écarte déjà l'essentiel des robots, qui ne
// l'exécutent pas. Googlebot, lui, le fait : sans ce filtre, les premiers mois
// d'un site neuf montreraient une courbe d'indexation prise pour de l'audience.
// Les robots ne sont pas jetés mais rangés à part : savoir que Google parcourt
// le site est en soi une information.
const ROBOT = /bot|crawl|spider|slurp|scrap|fetcher|monitor|preview|headless|phantom|lighthouse|pingdom|gtmetrix|curl|wget|python-requests|okhttp|java\/|go-http|libwww|semrush|ahrefs|mj12|dotbot|petal|bytespider|gptbot|claudebot|ccbot|perplexity|applebot|yandex|baidu|facebookexternalhit|embedly/i;

export const estRobot = (ua) => ROBOT.test(String(ua || '')) || !ua;

/** Chemin seul, assaini. Jamais la chaîne de requête : les liens de partage du
 *  calculateur y transportent la situation du visiteur — ressources, GIR. */
export function chemin(brut) {
  let s = String(brut == null ? '' : brut).split('?')[0].split('#')[0];
  if (s[0] !== '/') s = '/' + s;
  s = s.replace(/[^A-Za-z0-9/_.\-]/g, '').replace(/\/{2,}/g, '/');
  return (s.length > 120 ? s.slice(0, 120) : s) || '/';
}

export function domaine(brut) {
  const s = String(brut == null ? '' : brut).toLowerCase()
    .replace(/^www\./, '').replace(/[^a-z0-9.\-]/g, '');
  return s.length > 80 ? s.slice(0, 80) : s;
}

const entetes = (extra) => Object.assign({
  'Access-Control-Allow-Origin': ORIGINE,
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  'Cache-Control': 'no-store',
}, extra || {});

const json = (o, statut) => new Response(JSON.stringify(o),
  { status: statut || 200, headers: entetes({ 'Content-Type': 'application/json' }) });

const ech = (t) => String(t == null ? '' : t).replace(/[&<>"']/g,
  (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ── Enregistrement d'une vue
async function compte(request, env) {
  const u = new URL(request.url);
  const c = chemin(u.searchParams.get('p'));
  const d = domaine(u.searchParams.get('r'));
  const robot = estRobot(request.headers.get('User-Agent')) ? 1 : 0;
  // Une entrée est une arrivée depuis l'extérieur : referrer d'un autre site,
  // ou aucun referrer (accès direct). La navigation interne n'en est pas une.
  const entree = u.searchParams.get('e') === '1' ? 1 : 0;
  const { jour, heure } = quand(new Date());

  const ecritures = [
    env.DB.prepare(
      `INSERT INTO vues (jour, heure, chemin, robot, vues, entrees) VALUES (?, ?, ?, ?, 1, ?)
       ON CONFLICT(jour, heure, chemin, robot)
       DO UPDATE SET vues = vues + 1, entrees = entrees + excluded.entrees`)
      .bind(jour, heure, c, robot, entree),
  ];
  // Écrites seulement quand elles portent une information : une vue ordinaire
  // ne coûte qu'une écriture, ce qui garde le plafond gratuit à sa pleine valeur.
  if (d) {
    ecritures.push(env.DB.prepare(
      `INSERT INTO sources (jour, domaine, robot, vues) VALUES (?, ?, ?, 1)
       ON CONFLICT(jour, domaine, robot) DO UPDATE SET vues = vues + 1`)
      .bind(jour, d, robot));
  }
  const pays = (request.cf && request.cf.country) || request.headers.get('CF-IPCountry');
  if (entree && !robot && pays && /^[A-Z]{2}$/.test(pays)) {
    ecritures.push(env.DB.prepare(
      `INSERT INTO pays (jour, code, visites) VALUES (?, ?, 1)
       ON CONFLICT(jour, code) DO UPDATE SET visites = visites + 1`)
      .bind(jour, pays));
  }
  await env.DB.batch(ecritures);
  return new Response(null, { status: 204, headers: entetes() });
}

// ── Lecture
const PERIODES = {
  jour:    { sel: "jour",                        lib: 'Jour' },
  semaine: { sel: "strftime('%Y — S%W', jour)",   lib: 'Semaine' },
  mois:    { sel: "substr(jour, 1, 7)",           lib: 'Mois' },
};

async function releve(env, depuis) {
  const q = (sql, ...a) => env.DB.prepare(sql).bind(...a).all().then((r) => r.results || []);
  const par = async (k) => q(
    `SELECT ${PERIODES[k].sel} AS periode,
            SUM(CASE WHEN robot = 0 THEN vues    ELSE 0 END) AS vues,
            SUM(CASE WHEN robot = 0 THEN entrees ELSE 0 END) AS entrees,
            SUM(CASE WHEN robot = 1 THEN vues    ELSE 0 END) AS robots
       FROM vues WHERE jour >= ? GROUP BY periode ORDER BY periode DESC LIMIT 40`, depuis);
  const [jour, semaine, mois, pages, sources, pays, heures] = await Promise.all([
    par('jour'), par('semaine'), par('mois'),
    q(`SELECT chemin, SUM(vues) AS vues, SUM(entrees) AS entrees FROM vues
        WHERE jour >= ? AND robot = 0 GROUP BY chemin ORDER BY vues DESC LIMIT 25`, depuis),
    q(`SELECT domaine, SUM(vues) AS vues FROM sources
        WHERE jour >= ? AND robot = 0 GROUP BY domaine ORDER BY vues DESC LIMIT 25`, depuis),
    q(`SELECT code, SUM(visites) AS visites FROM pays
        WHERE jour >= ? GROUP BY code ORDER BY visites DESC LIMIT 25`, depuis),
    q(`SELECT heure, SUM(vues) AS vues FROM vues
        WHERE jour >= ? AND robot = 0 AND heure >= 0 GROUP BY heure ORDER BY heure`, depuis),
  ]);
  return { depuis, jour, semaine, mois, pages, sources, pays, heures };
}

function tableau(titre, lignes, colonnes) {
  if (!lignes.length) return `<h2>${ech(titre)}</h2><p class="v">Aucune donnée.</p>`;
  return `<h2>${ech(titre)}</h2><table><thead><tr>${
    colonnes.map((c) => `<th>${ech(c[0])}</th>`).join('')}</tr></thead><tbody>${
    lignes.map((l) => `<tr>${colonnes.map((c) =>
      `<td>${ech(l[c[1]] == null ? '—' : l[c[1]])}</td>`).join('')}</tr>`).join('')
  }</tbody></table>`;
}

function ecran(d) {
  const max = Math.max(1, ...d.heures.map((h) => h.vues));
  const profil = d.heures.length
    ? `<h2>Heures de consultation</h2><div class="h">${
        Array.from({ length: 24 }, (_, i) => {
          const v = (d.heures.find((x) => x.heure === i) || { vues: 0 }).vues;
          return `<i style="height:${Math.round((v / max) * 100)}%" title="${i}h : ${v}"></i>`;
        }).join('')}</div><p class="v">0 h à 23 h, heure de Paris.</p>`
    : '';
  return `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Audience — Trouver mon EHPAD</title>
<style>
:root{color-scheme:light dark}
body{margin:0;padding:1.5rem;font:15px/1.5 system-ui,sans-serif;max-width:60rem;margin-inline:auto}
h1{font-size:1.5rem;margin:0 0 .25rem}h2{font-size:1rem;margin:2rem 0 .5rem}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}
th,td{text-align:left;padding:.35rem .6rem;border-bottom:1px solid #8883}
td+td,th+th{text-align:right}
.v{color:#8a8a8a;font-size:.85rem}
.h{display:flex;align-items:flex-end;gap:2px;height:90px;margin-top:.5rem}
.h i{flex:1;background:#2548FF;min-height:1px;border-radius:2px 2px 0 0}
</style></head><body>
<h1>Audience</h1><p class="v">Depuis le ${ech(d.depuis)}. Heure de Paris.
Les robots identifiés sont comptés à part et jamais mêlés aux vues humaines.</p>
${tableau('Par jour', d.jour, [['Jour','periode'],['Vues','vues'],['Entrées','entrees'],['Robots','robots']])}
${tableau('Par semaine', d.semaine, [['Semaine','periode'],['Vues','vues'],['Entrées','entrees'],['Robots','robots']])}
${tableau('Par mois', d.mois, [['Mois','periode'],['Vues','vues'],['Entrées','entrees'],['Robots','robots']])}
${profil}
${tableau('Pages les plus vues', d.pages, [['Page','chemin'],['Vues','vues'],['Entrées','entrees']])}
${tableau('Sites référents', d.sources, [['Domaine','domaine'],['Vues','vues']])}
${tableau('Pays (sur les entrées)', d.pays, [['Pays','code'],['Visites','visites']])}
<p class="v" style="margin-top:2rem">Une vue est un chargement de page. Une entrée est une
arrivée depuis l'extérieur du site — la navigation interne n'en est pas une. Un visiteur qui
bloque les scripts n'est pas compté : aucun relevé de ce type n'est exhaustif.</p>
</body></html>`;
}

export default {
  async fetch(request, env) {
    const u = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: entetes() });

    if (u.pathname === '/v') {
      // Le relevé ne doit jamais faire échouer une page : toute erreur est avalée.
      try { return await compte(request, env); }
      catch (e) { return new Response(null, { status: 204, headers: entetes() }); }
    }

    if (u.pathname === '/mesure' || u.pathname === '/mesure.json') {
      if (!env.CLE_MESURE || u.searchParams.get('cle') !== env.CLE_MESURE) {
        return json({ erreur: 'interdit' }, 403);
      }
      const n = Math.min(1095, Math.max(1, Number(u.searchParams.get('jours')) || 90));
      const d = new Date(Date.now() - n * 86400000);
      const depuis = quand(d).jour;
      const releve_ = await releve(env, depuis);
      if (u.pathname === '/mesure.json') return json(releve_);
      return new Response(ecran(releve_), { headers: entetes({
        'Content-Type': 'text/html; charset=utf-8', 'X-Robots-Tag': 'noindex, nofollow' }) });
    }

    return json({ erreur: 'inconnu' }, 404);
  },

  /** Compactage : au-delà de 400 jours, les 24 lignes horaires d'une page
   *  deviennent une seule ligne (heure = -1). Le total du jour est conservé
   *  intact, le détail horaire est perdu, le volume divisé par vingt-quatre. */
  async scheduled(evt, env) {
    const seuil = quand(new Date(Date.now() - 400 * 86400000)).jour;
    await env.DB.prepare(
      `INSERT INTO vues (jour, heure, chemin, robot, vues, entrees)
       SELECT jour, -1, chemin, robot, SUM(vues), SUM(entrees) FROM vues
        WHERE jour < ? AND heure >= 0 GROUP BY jour, chemin, robot
       ON CONFLICT(jour, heure, chemin, robot)
       DO UPDATE SET vues = vues + excluded.vues, entrees = entrees + excluded.entrees`)
      .bind(seuil).run();
    await env.DB.prepare('DELETE FROM vues WHERE jour < ? AND heure >= 0').bind(seuil).run();
  },
};
